package com.ipsoft.demo.aspects;

public class ExceptionHandling {


}
